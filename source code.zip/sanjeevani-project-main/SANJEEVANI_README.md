# SANJEEVANI - When Seconds Matter

## 🎯 Project Overview
A modern, responsive, high-graphics, **frontend-only** healthcare donation demo website built for hackathon/demo purposes.

## ✅ Features Implemented

### Core Pages
1. **Home Page** - Hero section with animated particles, floating watermark, stats, and features
2. **Blood Donation Form** - Multi-step form with progress bar (4 steps)
3. **Organ Donation Form** - Multi-step form with document upload simulation (3 steps)
4. **Success Page** - Confetti animation, certificate with QR code, watermark background
5. **Donor Dashboard** - Stats, certificate preview, badges, benefits, recent activity
6. **Emergency Page** - Panic button, nearby donors list, emergency contacts
7. **Hospital Panel** - 4 tabs (Overview, Requests, Donors, Reports) with charts
8. **Medicine Store** - Product catalog, shopping cart, checkout simulation

### Design Elements
- ✅ **Glass Morphism** - Frosted glass cards with backdrop blur
- ✅ **Heavy Animations** - Particles, floating elements, transitions, hover effects
- ✅ **Red-Green-Blue Theme** - Medical colors throughout (Red for blood, Green for organ, Blue for support)
- ✅ **Floating Watermark** - Animated watermark moving from bottom to top infinitely
- ✅ **Responsive Design** - Mobile-first approach with Tailwind CSS
- ✅ **Modern Fonts** - Inter & Poppins from Google Fonts

### Technical Features
- ✅ React Router for navigation
- ✅ Framer Motion for animations
- ✅ Recharts for data visualization (Hospital Panel)
- ✅ QR Code generation for certificates
- ✅ Canvas Confetti for success celebrations
- ✅ Sonner for toast notifications
- ✅ Lucide React for beautiful icons

### Demo Mode Features
- All forms are fully functional in demo mode
- Success messages and simulated responses
- No backend/database/API calls
- Certificate generation with fake donor IDs
- Shopping cart with demo checkout
- Emergency alerts simulation
- Hospital analytics with fake data

## 🎨 Brand Assets
- **Logo**: Located at `/public/logo.jpeg` (Heart with medical cross design)
- **Watermark**: Located at `/public/watermark.png` (Used for floating background animation)

## 🚀 Tech Stack
- React 19
- React Router DOM 7.5
- Tailwind CSS 3.4
- Framer Motion 12
- Recharts 3.6
- Canvas Confetti
- QRCode.react
- Sonner (Toast notifications)
- Lucide React (Icons)

## 📁 Project Structure
```
/app/frontend/src/
├── components/
│   ├── AnimatedParticles.js
│   ├── FloatingWatermark.js
│   ├── Navbar.js
│   ├── Footer.js
│   ├── NotificationToast.js
│   └── ui/ (Shadcn components)
├── pages/
│   ├── HomePage.js
│   ├── BloodDonationForm.js
│   ├── OrganDonationForm.js
│   ├── SuccessPage.js
│   ├── DonorDashboard.js
│   ├── EmergencyPage.js
│   ├── HospitalPanel.js
│   └── MedicineStore.js
├── App.js
├── App.css
└── index.css
```

## 🎯 Key Highlights
1. **No Backend** - Pure frontend demo application
2. **Fully Functional UI** - All buttons and forms work in demo mode
3. **Beautiful Animations** - Particles, floating elements, smooth transitions
4. **Professional Design** - Glass morphism with medical color theme
5. **Mobile Responsive** - Works perfectly on all screen sizes
6. **Demo Notifications** - Toast messages for user actions
7. **Certificates** - Auto-generated with QR codes and watermarks
8. **Charts & Analytics** - Hospital panel with Recharts visualization

## 🔧 Installation & Setup
The project is already set up and running at `http://localhost:3000`

## 📝 Important Notes
- This is a **DEMO/HACKATHON** project
- No authentication or OTP system
- No actual payment processing
- All data is simulated/fake
- No server-side processing
- Perfect for showcasing UI/UX capabilities

## 🏆 Demo Features for Judges
1. Click through all forms - they work smoothly
2. See confetti animation on success page
3. Explore the dashboard with badges and benefits
4. Test emergency page with panic button
5. View hospital analytics with charts
6. Shop in medicine store with cart system
7. Notice the floating watermark on every page
8. See animated particles throughout the site

---

**Built with ❤️ for demonstrating modern healthcare tech solutions**
