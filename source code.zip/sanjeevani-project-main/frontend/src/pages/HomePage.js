import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Droplet, Heart, AlertCircle, Building2, Activity, Users, Award, Clock } from 'lucide-react';
import AnimatedParticles from '../components/AnimatedParticles';
import FloatingWatermark from '../components/FloatingWatermark';

const HomePage = () => {
  const features = [
    { icon: Droplet, title: 'Blood Donation', desc: 'Save lives by donating blood', color: 'red', link: '/donate-blood' },
    { icon: Heart, title: 'Organ Donation', desc: 'Gift of life for those in need', color: 'green', link: '/donate-organ' },
    { icon: AlertCircle, title: 'Emergency', desc: '24/7 urgent request service', color: 'blue', link: '/emergency' },
    { icon: Building2, title: 'Hospital Panel', desc: 'Manage requests efficiently', color: 'purple', link: '/hospital' },
  ];

  const stats = [
    { icon: Users, value: '50,000+', label: 'Active Donors' },
    { icon: Activity, value: '1,200+', label: 'Lives Saved' },
    { icon: Award, value: '500+', label: 'Hospitals Connected' },
    { icon: Clock, value: '24/7', label: 'Emergency Support' },
  ];

  return (
    <div className="relative min-h-screen overflow-hidden">
      <AnimatedParticles />
      <FloatingWatermark />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              animate={{
                scale: [1, 1.05, 1],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="inline-block mb-6"
            >
              <img
                src="/logo.jpeg"
                alt="Sanjeevani"
                className="h-32 w-32 mx-auto rounded-full logo-glow object-cover"
              />
            </motion.div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6">
              <span className="gradient-text">SANJEEVANI</span>
            </h1>
            <p className="text-2xl sm:text-3xl font-semibold text-gray-700 mb-4">
              When Seconds Matter
            </p>
            <p className="text-lg text-gray-600 mb-12 max-w-2xl mx-auto">
              Connecting Lives in Real Time. Be a hero today. Your donation can save lives.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/donate-blood">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-primary"
                  data-testid="donate-blood-btn"
                >
                  <Droplet className="inline mr-2" size={20} />
                  Donate Blood
                </motion.button>
              </Link>
              <Link to="/donate-organ">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-secondary"
                  data-testid="donate-organ-btn"
                >
                  <Heart className="inline mr-2" size={20} />
                  Donate Organ
                </motion.button>
              </Link>
              <Link to="/emergency">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-tertiary"
                  data-testid="emergency-btn"
                >
                  <AlertCircle className="inline mr-2" size={20} />
                  Emergency
                </motion.button>
              </Link>
              <Link to="/hospital">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-tertiary"
                  data-testid="hospital-panel-btn"
                >
                  <Building2 className="inline mr-2" size={20} />
                  Hospital Panel
                </motion.button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass-card p-6 text-center hover:shadow-2xl transition-shadow"
                data-testid={`stat-card-${index}`}
              >
                <stat.icon className="mx-auto mb-4 text-blue-500" size={48} />
                <h3 className="text-3xl font-bold text-gray-800 mb-2">{stat.value}</h3>
                <p className="text-gray-600">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-4xl font-bold text-center mb-12 gradient-text"
          >
            How We Help Save Lives
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05, y: -10 }}
                className="glass-card p-8 text-center cursor-pointer"
                data-testid={`feature-card-${index}`}
              >
                <Link to={feature.link}>
                  <div className={`inline-flex p-4 rounded-full bg-${feature.color}-100 mb-4`}>
                    <feature.icon className={`text-${feature.color}-500`} size={32} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.desc}</p>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="relative py-16 px-4 medical-gradient">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card p-12"
          >
            <h2 className="text-3xl font-bold mb-6 gradient-text">Why Choose Sanjeevani?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
              <div>
                <div className="text-red-500 mb-3">
                  <Clock size={40} />
                </div>
                <h3 className="font-semibold text-lg mb-2">Real-Time Matching</h3>
                <p className="text-gray-600">Instant connection between donors and recipients</p>
              </div>
              <div>
                <div className="text-green-500 mb-3">
                  <Award size={40} />
                </div>
                <h3 className="font-semibold text-lg mb-2">Verified Process</h3>
                <p className="text-gray-600">Secure and certified donation procedures</p>
              </div>
              <div>
                <div className="text-blue-500 mb-3">
                  <Users size={40} />
                </div>
                <h3 className="font-semibold text-lg mb-2">Growing Community</h3>
                <p className="text-gray-600">Join thousands of verified lifesavers</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass-card p-12"
          >
            <h2 className="text-4xl font-bold mb-6">Ready to Make a Difference?</h2>
            <p className="text-xl text-gray-600 mb-8">
              Every donation counts. Start your journey as a lifesaver today.
            </p>
            <Link to="/donate-blood">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-primary text-lg"
                data-testid="cta-donate-btn"
              >
                Get Started Now
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
