import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Clock, AlertCircle, FileText, Download, Eye } from 'lucide-react';
import FloatingWatermark from '../components/FloatingWatermark';
import AnimatedParticles from '../components/AnimatedParticles';
import DualWatermark from '../components/DualWatermark';

const UserStatusTracking = () => {
  const [activeTab, setActiveTab] = useState('status');

  const registrationStatus = {
    donorId: 'SDN12345ABC',
    registrationDate: '2024-12-15',
    donorType: 'Blood',
    bloodGroup: 'A+',
    status: 'Verified',
    lastUpdated: '2024-12-20',
  };

  const timeline = [
    { step: 'Registration Submitted', date: '2024-12-15', status: 'completed', icon: CheckCircle, color: 'green' },
    { step: 'Documents Under Review', date: '2024-12-16', status: 'completed', icon: CheckCircle, color: 'green' },
    { step: 'Medical Verification', date: '2024-12-18', status: 'completed', icon: CheckCircle, color: 'green' },
    { step: 'Approved & Certificate Issued', date: '2024-12-20', status: 'completed', icon: CheckCircle, color: 'green' },
    { step: 'Active Donor Status', date: 'Ongoing', status: 'active', icon: Clock, color: 'blue' },
  ];

  const documents = [
    { name: 'Aadhaar Card', status: 'Verified', date: '2024-12-16' },
    { name: 'Blood Report', status: 'Verified', date: '2024-12-17' },
    { name: 'Medical Certificate', status: 'Verified', date: '2024-12-18' },
    { name: 'Consent Form', status: 'Verified', date: '2024-12-15' },
  ];

  const notifications = [
    { type: 'success', message: 'Your registration has been approved!', date: '2024-12-20', read: false },
    { type: 'info', message: 'Certificate is ready for download', date: '2024-12-20', read: false },
    { type: 'info', message: 'Medical verification completed', date: '2024-12-18', read: true },
    { type: 'success', message: 'Documents submitted successfully', date: '2024-12-16', read: true },
  ];

  return (
    <div className="relative min-h-screen pt-24 pb-12 px-4">
      <AnimatedParticles />
      <FloatingWatermark />
      <DualWatermark />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl sm:text-5xl font-bold gradient-text mb-4">My Registration Status</h1>
          <p className="text-gray-600">Track your donation registration progress</p>
        </motion.div>

        {/* Donor ID Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card p-6 mb-8"
        >
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <img
                src="/logo.jpeg"
                alt="Sanjeevani"
                className="w-16 h-16 rounded-full object-cover"
              />
              <div>
                <h2 className="text-2xl font-bold text-gray-800">Donor ID: {registrationStatus.donorId}</h2>
                <p className="text-sm text-gray-600">Registered on {registrationStatus.registrationDate}</p>
              </div>
            </div>
            <div className="flex space-x-4">
              <div className="text-center px-6 py-3 bg-red-100 rounded-xl">
                <p className="text-xs text-gray-600">Blood Group</p>
                <p className="text-2xl font-bold text-red-600">{registrationStatus.bloodGroup}</p>
              </div>
              <div className="text-center px-6 py-3 bg-green-100 rounded-xl">
                <p className="text-xs text-gray-600">Status</p>
                <p className="text-lg font-bold text-green-600">{registrationStatus.status}</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {['status', 'documents', 'notifications'].map((tab) => (
            <motion.button
              key={tab}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-3 rounded-full font-semibold capitalize transition-all ${
                activeTab === tab
                  ? 'bg-gradient-to-r from-red-500 to-blue-500 text-white shadow-lg'
                  : 'bg-white/50 text-gray-700 hover:bg-white/70'
              }`}
              data-testid={`tab-${tab}`}
            >
              {tab}
            </motion.button>
          ))}
        </div>

        {/* Status Tab */}
        {activeTab === 'status' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            <div className="glass-card p-8">
              <h2 className="text-2xl font-bold mb-6 gradient-text">Registration Timeline</h2>
              <div className="space-y-6">
                {timeline.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-start space-x-4"
                  >
                    <div className="flex-shrink-0">
                      <div
                        className={`w-12 h-12 rounded-full flex items-center justify-center ${
                          item.status === 'completed'
                            ? 'bg-green-100'
                            : item.status === 'active'
                            ? 'bg-blue-100'
                            : 'bg-gray-100'
                        }`}
                      >
                        <item.icon
                          className={`${
                            item.status === 'completed'
                              ? 'text-green-600'
                              : item.status === 'active'
                              ? 'text-blue-600'
                              : 'text-gray-400'
                          }`}
                          size={24}
                        />
                      </div>
                    </div>
                    <div className="flex-1 pb-8 border-l-2 border-gray-200 pl-6 relative">
                      {index < timeline.length - 1 && (
                        <div className="absolute left-0 top-12 bottom-0 w-0.5 bg-gray-200" />
                      )}
                      <h3 className="font-semibold text-lg text-gray-800">{item.step}</h3>
                      <p className="text-sm text-gray-600">{item.date}</p>
                      {item.status === 'completed' && (
                        <span className="inline-block mt-2 px-3 py-1 bg-green-100 text-green-700 text-xs rounded-full font-semibold">
                          Completed
                        </span>
                      )}
                      {item.status === 'active' && (
                        <span className="inline-block mt-2 px-3 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-semibold animate-pulse">
                          Active
                        </span>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="glass-card p-6 text-center"
              >
                <div className="text-4xl mb-4">🩸</div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">5</h3>
                <p className="text-gray-600">Total Donations</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 }}
                className="glass-card p-6 text-center"
              >
                <div className="text-4xl mb-4">💝</div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">15</h3>
                <p className="text-gray-600">Lives Impacted</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                className="glass-card p-6 text-center"
              >
                <div className="text-4xl mb-4">🏆</div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">3</h3>
                <p className="text-gray-600">Badges Earned</p>
              </motion.div>
            </div>
          </motion.div>
        )}

        {/* Documents Tab */}
        {activeTab === 'documents' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="glass-card p-8"
          >
            <h2 className="text-2xl font-bold mb-6 gradient-text">Uploaded Documents</h2>
            <div className="space-y-4">
              {documents.map((doc, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-all"
                >
                  <div className="flex items-center space-x-4">
                    <FileText className="text-blue-500" size={32} />
                    <div>
                      <p className="font-semibold text-gray-800">{doc.name}</p>
                      <p className="text-sm text-gray-600">Submitted on {doc.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="px-4 py-2 bg-green-100 text-green-700 text-sm rounded-full font-semibold">
                      {doc.status}
                    </span>
                    <button
                      onClick={() => alert('View Document - Demo Mode')}
                      className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-all"
                    >
                      <Eye size={20} />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="mt-8 text-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => alert('Download Certificate - Demo Mode')}
                className="btn-primary flex items-center space-x-2 mx-auto"
              >
                <Download size={20} />
                <span>Download Certificate</span>
              </motion.button>
            </div>
          </motion.div>
        )}

        {/* Notifications Tab */}
        {activeTab === 'notifications' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="glass-card p-8"
          >
            <h2 className="text-2xl font-bold mb-6 gradient-text">Notifications</h2>
            <div className="space-y-4">
              {notifications.map((notification, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`p-4 rounded-xl transition-all ${
                    !notification.read ? 'bg-blue-50 border-2 border-blue-200' : 'bg-gray-50'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div
                        className={`p-2 rounded-lg ${
                          notification.type === 'success'
                            ? 'bg-green-100'
                            : notification.type === 'info'
                            ? 'bg-blue-100'
                            : 'bg-yellow-100'
                        }`}
                      >
                        {notification.type === 'success' ? (
                          <CheckCircle className="text-green-600" size={20} />
                        ) : notification.type === 'info' ? (
                          <AlertCircle className="text-blue-600" size={20} />
                        ) : (
                          <Clock className="text-yellow-600" size={20} />
                        )}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-800">{notification.message}</p>
                        <p className="text-sm text-gray-600">{notification.date}</p>
                      </div>
                    </div>
                    {!notification.read && (
                      <span className="px-3 py-1 bg-blue-500 text-white text-xs rounded-full font-semibold">
                        New
                      </span>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default UserStatusTracking;
