import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, Phone, MapPin, Clock, Droplet, Heart } from 'lucide-react';
import FloatingWatermark from '../components/FloatingWatermark';
import AnimatedParticles from '../components/AnimatedParticles';

const EmergencyPage = () => {
  const [isEmergency, setIsEmergency] = useState(false);
  const [countdown, setCountdown] = useState(0);

  const nearbyDonors = [
    { name: 'Rahul Sharma', bloodGroup: 'A+', distance: '1.2 km', available: true },
    { name: 'Priya Singh', bloodGroup: 'A+', distance: '1.8 km', available: true },
    { name: 'Amit Kumar', bloodGroup: 'A+', distance: '2.5 km', available: true },
    { name: 'Sneha Patel', bloodGroup: 'O+', distance: '3.1 km', available: false },
  ];

  useEffect(() => {
    if (isEmergency && countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [isEmergency, countdown]);

  const handleEmergency = () => {
    setIsEmergency(true);
    setCountdown(10);
    setTimeout(() => {
      alert('Emergency Alert Sent!\n\nDemo Mode: In production, this would notify nearby donors and hospitals instantly.');
    }, 1000);
  };

  return (
    <div className="relative min-h-screen pt-24 pb-12 px-4">
      <AnimatedParticles />
      <FloatingWatermark />

      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-red-100 mb-4 pulse-animation">
            <AlertCircle className="text-red-500" size={48} />
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold gradient-text mb-4">Emergency Blood Request</h1>
          <p className="text-gray-600">Get help in seconds - 24/7 support available</p>
        </motion.div>

        {!isEmergency ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass-card p-12 text-center"
          >
            <h2 className="text-2xl font-bold mb-6 text-gray-800">Need Blood Urgently?</h2>
            <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
              Click the panic button below to send an immediate alert to nearby donors and hospitals. 
              Our system will match you with the closest available donors in real-time.
            </p>

            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleEmergency}
              className="relative w-48 h-48 rounded-full bg-gradient-to-br from-red-500 to-red-700 text-white font-bold text-2xl shadow-2xl mx-auto pulse-animation"
              data-testid="panic-button"
            >
              <div className="absolute inset-0 rounded-full bg-red-400 animate-ping opacity-75"></div>
              <div className="relative z-10">
                <AlertCircle size={64} className="mx-auto mb-2" />
                <span>EMERGENCY</span>
              </div>
            </motion.button>

            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 bg-red-50 rounded-xl">
                <Clock className="text-red-500 mx-auto mb-3" size={32} />
                <h3 className="font-semibold mb-2">Instant Alert</h3>
                <p className="text-sm text-gray-600">Notify donors within seconds</p>
              </div>
              <div className="p-6 bg-green-50 rounded-xl">
                <MapPin className="text-green-500 mx-auto mb-3" size={32} />
                <h3 className="font-semibold mb-2">Location Based</h3>
                <p className="text-sm text-gray-600">Find nearest available donors</p>
              </div>
              <div className="p-6 bg-blue-50 rounded-xl">
                <Phone className="text-blue-500 mx-auto mb-3" size={32} />
                <h3 className="font-semibold mb-2">24/7 Support</h3>
                <p className="text-sm text-gray-600">Emergency helpline always active</p>
              </div>
            </div>
          </motion.div>
        ) : (
          <div className="space-y-6">
            {/* Alert Status */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card p-8 text-center"
              data-testid="alert-status"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 1, repeat: Infinity }}
                >
                  <AlertCircle className="text-green-500" size={32} />
                </motion.div>
              </div>
              <h2 className="text-3xl font-bold text-green-600 mb-2">Alert Sent Successfully!</h2>
              <p className="text-gray-600 mb-4">Notifying nearby donors and hospitals...</p>
              {countdown > 0 && (
                <p className="text-4xl font-bold text-blue-600">{countdown}</p>
              )}
            </motion.div>

            {/* Available Donors */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card p-8"
            >
              <h2 className="text-2xl font-bold mb-6 gradient-text">Nearby Available Donors</h2>
              <div className="space-y-4">
                {nearbyDonors.map((donor, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + index * 0.1 }}
                    className={`flex items-center justify-between p-4 rounded-xl transition-all ${
                      donor.available
                        ? 'bg-green-50 hover:bg-green-100 border-2 border-green-200'
                        : 'bg-gray-50 opacity-50'
                    }`}
                    data-testid={`donor-${index}`}
                  >
                    <div className="flex items-center space-x-4">
                      <div
                        className={`w-12 h-12 rounded-full flex items-center justify-center ${
                          donor.available ? 'bg-red-100' : 'bg-gray-200'
                        }`}
                      >
                        <Droplet className={donor.available ? 'text-red-500' : 'text-gray-400'} size={24} />
                      </div>
                      <div>
                        <p className="font-semibold text-gray-800">{donor.name}</p>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <span className="font-bold text-red-600">{donor.bloodGroup}</span>
                          <span>•</span>
                          <MapPin size={14} />
                          <span>{donor.distance}</span>
                        </div>
                      </div>
                    </div>
                    {donor.available ? (
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => alert(`Contacting ${donor.name} - Demo Mode`)}
                        className="px-4 py-2 bg-green-500 text-white rounded-full font-semibold hover:bg-green-600 transition-all"
                        data-testid={`contact-donor-${index}`}
                      >
                        Contact
                      </motion.button>
                    ) : (
                      <span className="px-4 py-2 bg-gray-300 text-gray-500 rounded-full font-semibold">
                        Unavailable
                      </span>
                    )}
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Emergency Contacts */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="glass-card p-8"
            >
              <h2 className="text-2xl font-bold mb-6 gradient-text">Emergency Contacts</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-4 p-4 bg-red-50 rounded-xl">
                  <Phone className="text-red-500" size={32} />
                  <div>
                    <p className="font-semibold text-gray-800">Emergency Helpline</p>
                    <p className="text-xl font-bold text-red-600">1800-123-4567</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4 p-4 bg-blue-50 rounded-xl">
                  <Phone className="text-blue-500" size={32} />
                  <div>
                    <p className="font-semibold text-gray-800">Ambulance Service</p>
                    <p className="text-xl font-bold text-blue-600">102 / 108</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {/* Safety Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-8 glass-card p-6 text-center"
        >
          <p className="text-sm text-gray-600">
            🛡️ This is a demo mode. In production, all emergency requests are verified and processed 
            through certified medical professionals and authorized blood banks.
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default EmergencyPage;
