import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Heart, Check, Upload, X, Eye, ZoomIn, FileText } from 'lucide-react';
import SignatureCanvas from 'react-signature-canvas';
import FloatingWatermark from '../components/FloatingWatermark';
import AnimatedParticles from '../components/AnimatedParticles';
import DualWatermark from '../components/DualWatermark';

const EnhancedOrganDonationForm = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [documents, setDocuments] = useState({
    aadhaar: null,
    bloodReport: null,
    policeReport: null,
    doctorReport: null,
    organReport: null,
  });
  const [previewDoc, setPreviewDoc] = useState(null);
  const signatureRef = useRef(null);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    dob: '',
    gender: '',
    address: '',
    emergencyContact: '',
    emergencyPhone: '',
    bloodGroup: '',
    organType: '',
    hospital: '',
    consent: false,
    signature: null,
  });

  const organTypes = ['Kidney', 'Liver', 'Heart', 'Lungs', 'Pancreas', 'Cornea', 'All Organs'];
  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const hospitals = ['City Hospital', 'General Hospital', 'Apollo Hospital', 'Max Hospital', 'Fortis Hospital'];

  const documentTypes = [
    { key: 'aadhaar', label: 'Aadhaar Card', icon: '🆔', required: true },
    { key: 'bloodReport', label: 'Blood Report', icon: '🩸', required: true },
    { key: 'policeReport', label: 'Police Verification', icon: '👮', required: false },
    { key: 'doctorReport', label: 'Doctor Certificate', icon: '⚕️', required: true },
    { key: 'organReport', label: 'Organ Health Report', icon: '🫀', required: true },
  ];

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const handleFileChange = (docType, e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setDocuments(prev => ({
          ...prev,
          [docType]: {
            file,
            preview: reader.result,
            name: file.name,
            size: (file.size / 1024).toFixed(2) + ' KB',
            type: file.type,
          },
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeDocument = (docType) => {
    setDocuments(prev => ({ ...prev, [docType]: null }));
  };

  const clearSignature = () => {
    if (signatureRef.current) {
      signatureRef.current.clear();
    }
  };

  const saveSignature = () => {
    if (signatureRef.current && !signatureRef.current.isEmpty()) {
      const signatureData = signatureRef.current.toDataURL();
      setFormData({ ...formData, signature: signatureData });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    saveSignature();
    const donorId = 'SDO' + Math.random().toString(36).substr(2, 9).toUpperCase();
    navigate('/success', { state: { donorId, type: 'organ', formData, documents } });
  };

  const nextStep = () => {
    if (step < 4) setStep(step + 1);
  };

  const prevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  return (
    <div className="relative min-h-screen pt-24 pb-12 px-4">
      <AnimatedParticles />
      <FloatingWatermark />
      <DualWatermark />

      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
            <Heart className="text-green-500" size={32} />
          </div>
          <h1 className="text-4xl font-bold gradient-text mb-2">Organ Donation Registration</h1>
          <p className="text-gray-600">The ultimate gift of life - Complete registration process</p>
        </motion.div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            {[1, 2, 3, 4].map((s) => (
              <div key={s} className="flex items-center flex-1">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all ${
                    s <= step
                      ? 'bg-gradient-to-r from-green-500 to-green-600 text-white scale-110 shadow-lg'
                      : 'bg-gray-200 text-gray-500'
                  }`}
                  data-testid={`step-indicator-${s}`}
                >
                  {s < step ? <Check size={20} /> : s}
                </div>
                {s < 4 && (
                  <div
                    className={`flex-1 h-2 mx-2 rounded-full transition-all ${
                      s < step ? 'bg-gradient-to-r from-green-500 to-green-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs text-gray-600 mt-2 px-2">
            <span>Personal Info</span>
            <span>Documents</span>
            <span>Signature & Consent</span>
            <span>Review</span>
          </div>
        </div>

        {/* Form */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card p-8"
        >
          <form onSubmit={handleSubmit}>
            <AnimatePresence mode="wait">
              {/* Step 1: Personal Information */}
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  className="space-y-4"
                >
                  <h2 className="text-2xl font-semibold mb-6 text-gray-800">Personal Information</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                        placeholder="Enter your full name"
                        data-testid="input-name"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Gender *</label>
                      <select
                        name="gender"
                        value={formData.gender}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                        data-testid="select-gender"
                      >
                        <option value="">Select Gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                        placeholder="+91 XXXXX XXXXX"
                        data-testid="input-phone"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                        placeholder="your.email@example.com"
                        data-testid="input-email"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Date of Birth *</label>
                      <input
                        type="date"
                        name="dob"
                        value={formData.dob}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                        data-testid="input-dob"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Blood Group *</label>
                      <select
                        name="bloodGroup"
                        value={formData.bloodGroup}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                        data-testid="select-blood-group"
                      >
                        <option value="">Select Blood Group</option>
                        {bloodGroups.map((group) => (
                          <option key={group} value={group}>{group}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Organ Type *</label>
                      <select
                        name="organType"
                        value={formData.organType}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                        data-testid="select-organ-type"
                      >
                        <option value="">Select Organ Type</option>
                        {organTypes.map((organ) => (
                          <option key={organ} value={organ}>{organ}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Hospital *</label>
                      <select
                        name="hospital"
                        value={formData.hospital}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                        data-testid="select-hospital"
                      >
                        <option value="">Select Hospital</option>
                        {hospitals.map((hospital) => (
                          <option key={hospital} value={hospital}>{hospital}</option>
                        ))}
                      </select>
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Full Address *</label>
                      <textarea
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        required
                        rows="3"
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                        placeholder="Enter your complete address"
                        data-testid="textarea-address"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Emergency Contact Name *</label>
                      <input
                        type="text"
                        name="emergencyContact"
                        value={formData.emergencyContact}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                        placeholder="Contact person name"
                        data-testid="input-emergency-contact"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Emergency Contact Phone *</label>
                      <input
                        type="tel"
                        name="emergencyPhone"
                        value={formData.emergencyPhone}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                        placeholder="+91 XXXXX XXXXX"
                        data-testid="input-emergency-phone"
                      />
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 2: Document Upload with Preview */}
              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  className="space-y-6"
                >
                  <h2 className="text-2xl font-semibold mb-6 text-gray-800">Upload Documents</h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {documentTypes.map((doc) => (
                      <div key={doc.key} className="glass-card p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            <span className="text-2xl">{doc.icon}</span>
                            <div>
                              <p className="font-semibold text-sm">{doc.label}</p>
                              {doc.required && <span className="text-xs text-red-500">Required</span>}
                            </div>
                          </div>
                        </div>

                        {!documents[doc.key] ? (
                          <label className="block">
                            <input
                              type="file"
                              onChange={(e) => handleFileChange(doc.key, e)}
                              accept=".pdf,.jpg,.jpeg,.png"
                              className="hidden"
                              id={`upload-${doc.key}`}
                            />
                            <div className="border-2 border-dashed border-gray-300 rounded-xl p-4 text-center hover:border-green-500 transition-all cursor-pointer">
                              <Upload className="mx-auto mb-2 text-gray-400" size={24} />
                              <p className="text-xs text-gray-600">Click to upload</p>
                              <p className="text-xs text-gray-400">PDF, JPG, PNG (Max 5MB)</p>
                            </div>
                          </label>
                        ) : (
                          <div className="space-y-2">
                            <div className="flex items-center justify-between p-3 bg-green-50 rounded-xl">
                              <div className="flex items-center space-x-2 flex-1 min-w-0">
                                <FileText className="text-green-600 flex-shrink-0" size={20} />
                                <div className="min-w-0 flex-1">
                                  <p className="text-sm font-medium text-gray-800 truncate">
                                    {documents[doc.key].name}
                                  </p>
                                  <p className="text-xs text-gray-500">{documents[doc.key].size}</p>
                                </div>
                              </div>
                              <div className="flex space-x-2 ml-2">
                                <button
                                  type="button"
                                  onClick={() => setPreviewDoc(documents[doc.key])}
                                  className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-all"
                                >
                                  <Eye size={16} />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => removeDocument(doc.key)}
                                  className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-all"
                                >
                                  <X size={16} />
                                </button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                    <p className="text-sm text-blue-800">
                      📄 Demo Mode: Documents are stored locally for preview. In production, these would be securely encrypted and stored.
                    </p>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Digital Signature & Consent */}
              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  className="space-y-6"
                >
                  <h2 className="text-2xl font-semibold mb-6 text-gray-800">Digital Signature & Consent</h2>
                  
                  <div className="bg-gray-50 p-6 rounded-xl">
                    <h3 className="font-semibold text-lg mb-4">Organ Donation Declaration</h3>
                    <div className="space-y-3 text-sm text-gray-700 max-h-64 overflow-y-auto">
                      <p>
                        I, <strong>{formData.name || '[Your Name]'}</strong>, hereby voluntarily declare my wish to donate my organ(s) 
                        as specified in this registration form after my death.
                      </p>
                      <p>
                        I understand that this is an act of selfless charity and neither I nor my family will receive 
                        any monetary compensation for this donation. I am aware that organ donation can save or significantly 
                        improve the quality of life of recipients.
                      </p>
                      <p>
                        I confirm that I am mentally sound, of legal age, and understand the implications of this decision. 
                        I have read and understood all terms and conditions related to organ donation as per applicable laws.
                      </p>
                      <p>
                        I authorize qualified medical professionals to harvest the specified organ(s) for transplantation 
                        purposes and to use them to save the lives of patients in need.
                      </p>
                      <p>
                        I understand that this registration can be withdrawn at any time by notifying the concerned authorities 
                        in writing.
                      </p>
                    </div>
                  </div>

                  <div className="glass-card p-6">
                    <h3 className="font-semibold mb-4">Digital Signature</h3>
                    <div className="border-2 border-gray-300 rounded-xl overflow-hidden mb-4">
                      <SignatureCanvas
                        ref={signatureRef}
                        canvasProps={{
                          className: 'w-full h-48 bg-white',
                        }}
                      />
                    </div>
                    <button
                      type="button"
                      onClick={clearSignature}
                      className="px-4 py-2 bg-gray-200 text-gray-700 rounded-full hover:bg-gray-300 transition-all"
                    >
                      Clear Signature
                    </button>
                  </div>

                  <div className="flex items-start space-x-3 p-4 bg-green-50 rounded-xl border-2 border-green-200">
                    <input
                      type="checkbox"
                      name="consent"
                      checked={formData.consent}
                      onChange={handleChange}
                      required
                      className="mt-1 w-5 h-5 text-green-500 focus:ring-green-500 rounded"
                      data-testid="checkbox-consent"
                    />
                    <label className="text-sm text-gray-700">
                      <span className="font-semibold">I agree and consent</span> to all the terms and conditions mentioned above. 
                      I understand this is a demo application and no actual organ donation will be processed. My signature above 
                      represents my acknowledgment of this declaration.
                    </label>
                  </div>
                </motion.div>
              )}

              {/* Step 4: Review & Submit */}
              {step === 4 && (
                <motion.div
                  key="step4"
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  className="space-y-6"
                >
                  <h2 className="text-2xl font-semibold mb-6 text-gray-800">Review Your Information</h2>
                  
                  <div className="glass-card p-6">
                    <h3 className="font-semibold text-lg mb-4 text-green-600">Personal Details</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Name</p>
                        <p className="font-semibold">{formData.name}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Gender</p>
                        <p className="font-semibold capitalize">{formData.gender}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Blood Group</p>
                        <p className="font-semibold text-red-600">{formData.bloodGroup}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Organ Type</p>
                        <p className="font-semibold text-green-600">{formData.organType}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Phone</p>
                        <p className="font-semibold">{formData.phone}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Email</p>
                        <p className="font-semibold">{formData.email}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Hospital</p>
                        <p className="font-semibold">{formData.hospital}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Emergency Contact</p>
                        <p className="font-semibold">{formData.emergencyContact}</p>
                      </div>
                    </div>
                  </div>

                  <div className="glass-card p-6">
                    <h3 className="font-semibold text-lg mb-4 text-blue-600">Documents Uploaded</h3>
                    <div className="space-y-2">
                      {documentTypes.map((doc) => (
                        <div key={doc.key} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                          <div className="flex items-center space-x-2">
                            <span>{doc.icon}</span>
                            <span className="text-sm">{doc.label}</span>
                          </div>
                          {documents[doc.key] ? (
                            <span className="text-xs px-3 py-1 bg-green-100 text-green-700 rounded-full font-semibold">
                              ✓ Uploaded
                            </span>
                          ) : (
                            <span className="text-xs px-3 py-1 bg-gray-200 text-gray-600 rounded-full">
                              Not uploaded
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {formData.signature && (
                    <div className="glass-card p-6">
                      <h3 className="font-semibold text-lg mb-4 text-purple-600">Your Signature</h3>
                      <img src={formData.signature} alt="Signature" className="border-2 border-gray-300 rounded-xl max-h-32" />
                    </div>
                  )}

                  <div className="bg-green-50 border-2 border-green-200 rounded-xl p-4">
                    <p className="text-sm text-green-800">
                      ✓ All information verified. Click Submit to complete your organ donation registration.
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8">
              {step > 1 && (
                <motion.button
                  type="button"
                  onClick={prevStep}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 py-3 rounded-full border-2 border-gray-300 text-gray-700 font-semibold flex items-center space-x-2 hover:bg-gray-50 transition-all"
                  data-testid="btn-previous"
                >
                  <ChevronLeft size={20} />
                  <span>Previous</span>
                </motion.button>
              )}

              {step < 4 ? (
                <motion.button
                  type="button"
                  onClick={nextStep}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-secondary ml-auto flex items-center space-x-2"
                  data-testid="btn-next"
                >
                  <span>Next</span>
                  <ChevronRight size={20} />
                </motion.button>
              ) : (
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-secondary ml-auto flex items-center space-x-2"
                  data-testid="btn-submit"
                >
                  <Check size={20} />
                  <span>Submit Registration</span>
                </motion.button>
              )}
            </div>
          </form>
        </motion.div>
      </div>

      {/* Document Preview Modal */}
      {previewDoc && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setPreviewDoc(null)}
        >
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            className="bg-white rounded-2xl p-6 max-w-4xl max-h-[90vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold">Document Preview</h3>
              <button
                onClick={() => setPreviewDoc(null)}
                className="p-2 hover:bg-gray-100 rounded-full transition-all"
              >
                <X size={24} />
              </button>
            </div>
            <img 
              src={previewDoc.preview} 
              alt="Document preview" 
              className="w-full rounded-xl shadow-lg"
            />
            <p className="mt-4 text-sm text-gray-600">
              {previewDoc.name} • {previewDoc.size}
            </p>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};

export default EnhancedOrganDonationForm;
