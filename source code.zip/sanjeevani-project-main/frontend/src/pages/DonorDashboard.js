import React from 'react';
import { motion } from 'framer-motion';
import { Award, Heart, Droplet, Calendar, Bell, Gift, Trophy, Star } from 'lucide-react';
import FloatingWatermark from '../components/FloatingWatermark';
import AnimatedParticles from '../components/AnimatedParticles';

const DonorDashboard = () => {
  const donorStats = {
    name: 'Demo User',
    donorId: 'SDN12345ABC',
    bloodGroup: 'A+',
    totalDonations: 5,
    livesImpacted: 15,
    badges: 3,
    nextEligible: '2025-03-15',
  };

  const badges = [
    { icon: '🌟', name: 'First Donation', color: 'yellow' },
    { icon: '💪', name: 'Regular Donor', color: 'blue' },
    { icon: '🏆', name: 'Life Saver', color: 'red' },
  ];

  const benefits = [
    'Free health checkup every 6 months',
    'Priority medical assistance',
    'Tax benefits (Demo)',
    'Exclusive donor card',
    'Recognition certificate',
  ];

  const recentActivity = [
    { date: '2024-09-15', type: 'Blood Donation', hospital: 'City Hospital', status: 'Completed' },
    { date: '2024-06-20', type: 'Blood Donation', hospital: 'Max Hospital', status: 'Completed' },
    { date: '2024-03-10', type: 'Blood Donation', hospital: 'Apollo Hospital', status: 'Completed' },
  ];

  return (
    <div className="relative min-h-screen pt-24 pb-12 px-4">
      <AnimatedParticles />
      <FloatingWatermark />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl sm:text-5xl font-bold gradient-text mb-4">Donor Dashboard</h1>
          <p className="text-gray-600">Welcome back, {donorStats.name}!</p>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            className="glass-card p-6"
            data-testid="stat-card-donations"
          >
            <Droplet className="text-red-500 mb-3" size={32} />
            <h3 className="text-3xl font-bold text-gray-800">{donorStats.totalDonations}</h3>
            <p className="text-gray-600">Total Donations</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="glass-card p-6"
            data-testid="stat-card-lives"
          >
            <Heart className="text-green-500 mb-3" size={32} />
            <h3 className="text-3xl font-bold text-gray-800">{donorStats.livesImpacted}</h3>
            <p className="text-gray-600">Lives Impacted</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="glass-card p-6"
            data-testid="stat-card-badges"
          >
            <Award className="text-blue-500 mb-3" size={32} />
            <h3 className="text-3xl font-bold text-gray-800">{donorStats.badges}</h3>
            <p className="text-gray-600">Badges Earned</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            className="glass-card p-6"
            data-testid="stat-card-eligible"
          >
            <Calendar className="text-purple-500 mb-3" size={32} />
            <h3 className="text-lg font-bold text-gray-800">{donorStats.nextEligible}</h3>
            <p className="text-gray-600">Next Eligible Date</p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Certificate Preview */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-card p-8"
            >
              <h2 className="text-2xl font-bold mb-6 gradient-text">Your Certificate</h2>
              <div className="bg-gradient-to-br from-red-50 via-green-50 to-blue-50 p-8 rounded-2xl text-center relative overflow-hidden">
                <div className="absolute inset-0 opacity-5">
                  <img src="/watermark.png" alt="" className="w-full h-full object-contain" />
                </div>
                <div className="relative z-10">
                  <img
                    src="/logo.jpeg"
                    alt="Sanjeevani"
                    className="h-16 w-16 mx-auto rounded-full object-cover mb-4"
                  />
                  <h3 className="text-2xl font-bold mb-2">{donorStats.name}</h3>
                  <p className="text-gray-600 mb-4">Donor ID: {donorStats.donorId}</p>
                  <div className="inline-block bg-red-100 px-6 py-3 rounded-full">
                    <p className="text-sm text-gray-600">Blood Group</p>
                    <p className="text-2xl font-bold text-red-600">{donorStats.bloodGroup}</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Recent Activity */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card p-8"
            >
              <h2 className="text-2xl font-bold mb-6 gradient-text">Recent Activity</h2>
              <div className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-all"
                    data-testid={`activity-${index}`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                        <Droplet className="text-red-500" size={24} />
                      </div>
                      <div>
                        <p className="font-semibold text-gray-800">{activity.type}</p>
                        <p className="text-sm text-gray-600">{activity.hospital}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">{activity.date}</p>
                      <span className="inline-block px-3 py-1 bg-green-100 text-green-700 text-xs rounded-full font-semibold">
                        {activity.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Badges */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-card p-6"
            >
              <h2 className="text-xl font-bold mb-4 gradient-text">Your Badges</h2>
              <div className="space-y-3">
                {badges.map((badge, index) => (
                  <div
                    key={index}
                    className="flex items-center space-x-3 p-3 bg-gray-50 rounded-xl hover:scale-105 transition-transform"
                    data-testid={`badge-${index}`}
                  >
                    <span className="text-3xl">{badge.icon}</span>
                    <span className="font-semibold text-gray-800">{badge.name}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Benefits */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-card p-6"
            >
              <h2 className="text-xl font-bold mb-4 gradient-text">Donor Benefits</h2>
              <ul className="space-y-2">
                {benefits.map((benefit, index) => (
                  <li key={index} className="flex items-start space-x-2 text-gray-700">
                    <Gift className="text-green-500 flex-shrink-0 mt-1" size={16} />
                    <span className="text-sm">{benefit}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* Notifications */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="glass-card p-6"
            >
              <h2 className="text-xl font-bold mb-4 gradient-text">Notifications</h2>
              <div className="space-y-3">
                <div className="flex items-start space-x-3 p-3 bg-blue-50 rounded-xl">
                  <Bell className="text-blue-500 flex-shrink-0 mt-1" size={20} />
                  <p className="text-sm text-gray-700">
                    You're eligible to donate again! Schedule your next donation.
                  </p>
                </div>
                <div className="flex items-start space-x-3 p-3 bg-green-50 rounded-xl">
                  <Trophy className="text-green-500 flex-shrink-0 mt-1" size={20} />
                  <p className="text-sm text-gray-700">
                    Congratulations! You've earned the "Life Saver" badge.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DonorDashboard;
