import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, Plus, Minus, ShoppingCart, CheckCircle } from 'lucide-react';
import FloatingWatermark from '../components/FloatingWatermark';
import AnimatedParticles from '../components/AnimatedParticles';

const MedicineStore = () => {
  const [cart, setCart] = useState([]);
  const [showCheckout, setShowCheckout] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);

  const medicines = [
    { id: 1, name: 'Paracetamol 500mg', price: 50, category: 'Pain Relief', image: '💊' },
    { id: 2, name: 'Vitamin D3', price: 250, category: 'Supplements', image: '🧪' },
    { id: 3, name: 'Cough Syrup', price: 120, category: 'Cold & Flu', image: '🍯' },
    { id: 4, name: 'Bandage Roll', price: 80, category: 'First Aid', image: '🩹' },
    { id: 5, name: 'Hand Sanitizer', price: 60, category: 'Hygiene', image: '🧴' },
    { id: 6, name: 'Face Masks (Pack of 10)', price: 100, category: 'Protection', image: '😷' },
    { id: 7, name: 'Thermometer', price: 450, category: 'Devices', image: '🌡️' },
    { id: 8, name: 'Blood Pressure Monitor', price: 1200, category: 'Devices', image: '⚕️' },
  ];

  const addToCart = (medicine) => {
    const existing = cart.find((item) => item.id === medicine.id);
    if (existing) {
      setCart(cart.map((item) =>
        item.id === medicine.id ? { ...item, quantity: item.quantity + 1 } : item
      ));
    } else {
      setCart([...cart, { ...medicine, quantity: 1 }]);
    }
  };

  const removeFromCart = (id) => {
    const existing = cart.find((item) => item.id === id);
    if (existing.quantity === 1) {
      setCart(cart.filter((item) => item.id !== id));
    } else {
      setCart(cart.map((item) =>
        item.id === id ? { ...item, quantity: item.quantity - 1 } : item
      ));
    }
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const handleCheckout = () => {
    setShowCheckout(true);
  };

  const handlePlaceOrder = (e) => {
    e.preventDefault();
    setOrderPlaced(true);
    setTimeout(() => {
      setCart([]);
      setShowCheckout(false);
      setOrderPlaced(false);
    }, 3000);
  };

  return (
    <div className="relative min-h-screen pt-24 pb-12 px-4">
      <AnimatedParticles />
      <FloatingWatermark />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-purple-100 mb-4">
            <ShoppingBag className="text-purple-500" size={32} />
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold gradient-text mb-4">Medicine Store</h1>
          <p className="text-gray-600">Essential medicines and healthcare products</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Products */}
          <div className="lg:col-span-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {medicines.map((medicine, index) => (
                <motion.div
                  key={medicine.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ scale: 1.05 }}
                  className="glass-card p-6 cursor-pointer"
                  data-testid={`medicine-${medicine.id}`}
                >
                  <div className="text-6xl mb-4 text-center">{medicine.image}</div>
                  <div className="mb-2">
                    <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-semibold">
                      {medicine.category}
                    </span>
                  </div>
                  <h3 className="font-semibold text-lg text-gray-800 mb-2">{medicine.name}</h3>
                  <p className="text-2xl font-bold text-green-600 mb-4">₹{medicine.price}</p>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => addToCart(medicine)}
                    className="w-full btn-secondary flex items-center justify-center space-x-2"
                    data-testid={`add-to-cart-${medicine.id}`}
                  >
                    <Plus size={20} />
                    <span>Add to Cart</span>
                  </motion.button>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Cart */}
          <div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-card p-6 sticky top-24"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold gradient-text">Cart</h2>
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-red-500 text-white font-bold">
                  {cart.reduce((total, item) => total + item.quantity, 0)}
                </div>
              </div>

              {cart.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingCart className="mx-auto mb-4 text-gray-400" size={64} />
                  <p className="text-gray-600">Your cart is empty</p>
                </div>
              ) : (
                <>
                  <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
                    {cart.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-4 bg-gray-50 rounded-xl"
                        data-testid={`cart-item-${item.id}`}
                      >
                        <div className="flex items-center space-x-3">
                          <span className="text-3xl">{item.image}</span>
                          <div>
                            <p className="font-semibold text-sm">{item.name}</p>
                            <p className="text-green-600 font-bold">₹{item.price}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => removeFromCart(item.id)}
                            className="w-8 h-8 rounded-full bg-red-100 text-red-600 flex items-center justify-center hover:bg-red-200 transition-all"
                            data-testid={`decrease-${item.id}`}
                          >
                            <Minus size={16} />
                          </button>
                          <span className="w-8 text-center font-bold">{item.quantity}</span>
                          <button
                            onClick={() => addToCart(item)}
                            className="w-8 h-8 rounded-full bg-green-100 text-green-600 flex items-center justify-center hover:bg-green-200 transition-all"
                            data-testid={`increase-${item.id}`}
                          >
                            <Plus size={16} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-gray-200 pt-4 mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-600">Subtotal</span>
                      <span className="font-semibold">₹{getTotalPrice()}</span>
                    </div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-600">Delivery</span>
                      <span className="font-semibold text-green-600">FREE</span>
                    </div>
                    <div className="flex justify-between items-center text-xl font-bold">
                      <span>Total</span>
                      <span className="text-green-600">₹{getTotalPrice()}</span>
                    </div>
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleCheckout}
                    className="w-full btn-primary"
                    data-testid="checkout-btn"
                  >
                    Proceed to Checkout
                  </motion.button>
                </>
              )}
            </motion.div>
          </div>
        </div>

        {/* Checkout Modal */}
        {showCheckout && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => !orderPlaced && setShowCheckout(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="glass-card p-8 max-w-md w-full"
              onClick={(e) => e.stopPropagation()}
              data-testid="checkout-modal"
            >
              {!orderPlaced ? (
                <>
                  <h2 className="text-2xl font-bold gradient-text mb-6">Checkout</h2>
                  <form onSubmit={handlePlaceOrder} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                      <input
                        type="text"
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
                        placeholder="Enter your name"
                        data-testid="checkout-name"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                      <input
                        type="tel"
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
                        placeholder="+91 XXXXX XXXXX"
                        data-testid="checkout-phone"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Delivery Address</label>
                      <textarea
                        required
                        rows="3"
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
                        placeholder="Enter delivery address"
                        data-testid="checkout-address"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
                      <select
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
                        data-testid="checkout-payment"
                      >
                        <option value="">Select Payment</option>
                        <option value="cod">Cash on Delivery</option>
                        <option value="upi">UPI</option>
                        <option value="card">Card (Demo)</option>
                      </select>
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                      <p className="text-sm text-blue-800">
                        💳 Demo Mode: Payment processing simulated. No actual transaction will occur.
                      </p>
                    </div>

                    <div className="flex space-x-4">
                      <button
                        type="button"
                        onClick={() => setShowCheckout(false)}
                        className="flex-1 px-6 py-3 rounded-full border-2 border-gray-300 text-gray-700 font-semibold hover:bg-gray-50 transition-all"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex-1 btn-primary"
                        data-testid="place-order-btn"
                      >
                        Place Order
                      </button>
                    </div>
                  </form>
                </>
              ) : (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="text-center"
                >
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  >
                    <CheckCircle className="text-green-500 mx-auto mb-4" size={80} />
                  </motion.div>
                  <h2 className="text-3xl font-bold text-green-600 mb-2">Order Placed!</h2>
                  <p className="text-gray-600 mb-4">Thank you for your order</p>
                  <p className="text-sm text-gray-500">Order ID: MED{Math.random().toString(36).substr(2, 9).toUpperCase()}</p>
                </motion.div>
              )}
            </motion.div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default MedicineStore;
