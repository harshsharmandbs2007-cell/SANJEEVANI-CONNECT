import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Heart, Check, Upload, X, Eye, ZoomIn } from 'lucide-react';
import SignatureCanvas from 'react-signature-canvas';
import FloatingWatermark from '../components/FloatingWatermark';
import AnimatedParticles from '../components/AnimatedParticles';
import DualWatermark from '../components/DualWatermark';

const OrganDonationForm = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [documents, setDocuments] = useState({
    aadhaar: null,
    bloodReport: null,
    policeReport: null,
    doctorReport: null,
    organReport: null,
  });
  const [previewDoc, setPreviewDoc] = useState(null);
  const signatureRef = useRef(null);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    dob: '',
    gender: '',
    address: '',
    emergencyContact: '',
    organType: '',
    consent: false,
    signature: null,
  });

  const organTypes = ['Kidney', 'Liver', 'Heart', 'Lungs', 'Pancreas', 'Cornea', 'All Organs'];

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const handleFileChange = (docType, file) => {
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setDocuments(prev => ({
          ...prev,
          [docType]: {
            file,
            preview: reader.result,
            name: file.name,
            size: (file.size / 1024).toFixed(2) + ' KB',
          },
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeDocument = (docType) => {
    setDocuments(prev => ({ ...prev, [docType]: null }));
  };

  const clearSignature = () => {
    if (signatureRef.current) {
      signatureRef.current.clear();
    }
  };

  const saveSignature = () => {
    if (signatureRef.current && !signatureRef.current.isEmpty()) {
      const signatureData = signatureRef.current.toDataURL();
      setFormData({ ...formData, signature: signatureData });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    saveSignature();
    const donorId = 'SDO' + Math.random().toString(36).substr(2, 9).toUpperCase();
    navigate('/success', { state: { donorId, type: 'organ', formData, documents } });
  };

  const nextStep = () => {
    if (step < 3) setStep(step + 1);
  };

  const prevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  return (
    <div className="relative min-h-screen pt-24 pb-12 px-4">
      <AnimatedParticles />
      <FloatingWatermark />
      <DualWatermark />

      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
            <Heart className="text-green-500" size={32} />
          </div>
          <h1 className="text-4xl font-bold gradient-text mb-2">Organ Donation</h1>
          <p className="text-gray-600">The ultimate gift of life</p>
        </motion.div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            {[1, 2, 3, 4].map((s) => (
              <div key={s} className="flex items-center flex-1">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all ${
                    s <= step
                      ? 'bg-gradient-to-r from-green-500 to-green-600 text-white scale-110'
                      : 'bg-gray-200 text-gray-500'
                  }`}
                  data-testid={`step-indicator-${s}`}
                >
                  {s < step ? <Check size={20} /> : s}
                </div>
                {s < 4 && (
                  <div
                    className={`flex-1 h-2 mx-2 rounded-full transition-all ${
                      s < step ? 'bg-gradient-to-r from-green-500 to-green-600' : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs text-gray-600 mt-2">
            <span>Personal</span>
            <span>Documents</span>
            <span>Signature</span>
            <span>Review</span>
          </div>
        </div>

        {/* Form */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card p-8"
        >
          <form onSubmit={handleSubmit}>
            <AnimatePresence mode="wait">
              {/* Step 1: Personal Information */}
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  className="space-y-4"
                >
                  <h2 className="text-2xl font-semibold mb-6 text-gray-800">Personal Information</h2>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                      placeholder="Enter your full name"
                      data-testid="input-name"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                      placeholder="+91 XXXXX XXXXX"
                      data-testid="input-phone"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                      placeholder="your.email@example.com"
                      data-testid="input-email"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Date of Birth *</label>
                    <input
                      type="date"
                      name="dob"
                      value={formData.dob}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                      data-testid="input-dob"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Organ Type *</label>
                    <select
                      name="organType"
                      value={formData.organType}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-all"
                      data-testid="select-organ-type"
                    >
                      <option value="">Select Organ Type</option>
                      {organTypes.map((organ) => (
                        <option key={organ} value={organ}>
                          {organ}
                        </option>
                      ))}
                    </select>
                  </div>
                </motion.div>
              )}

              {/* Step 2: Document Upload */}
              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  className="space-y-4"
                >
                  <h2 className="text-2xl font-semibold mb-6 text-gray-800">Document Upload</h2>
                  
                  <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-green-500 transition-all">
                    <Upload className="mx-auto mb-4 text-gray-400" size={48} />
                    <input
                      type="file"
                      onChange={handleFileChange}
                      className="hidden"
                      id="document-upload"
                      accept=".pdf,.jpg,.jpeg,.png"
                      data-testid="input-file"
                    />
                    <label htmlFor="document-upload" className="cursor-pointer">
                      <p className="text-lg font-semibold text-gray-700 mb-2">
                        {formData.document ? formData.document.name : 'Upload ID Proof'}
                      </p>
                      <p className="text-sm text-gray-500">
                        PDF, JPG, PNG (Max 5MB) - Demo Mode
                      </p>
                      <button
                        type="button"
                        onClick={() => document.getElementById('document-upload').click()}
                        className="mt-4 px-6 py-2 bg-green-100 text-green-700 rounded-full font-semibold hover:bg-green-200 transition-all"
                      >
                        Choose File
                      </button>
                    </label>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                    <p className="text-sm text-blue-800">
                      📄 Demo Mode: File upload is simulated. In production, documents would be securely stored and verified.
                    </p>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Consent */}
              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  className="space-y-4"
                >
                  <h2 className="text-2xl font-semibold mb-6 text-gray-800">Consent & Declaration</h2>
                  
                  <div className="bg-gray-50 p-6 rounded-xl space-y-4 max-h-64 overflow-y-auto">
                    <h3 className="font-semibold text-lg">Organ Donation Consent</h3>
                    <p className="text-sm text-gray-700">
                      I hereby declare that I am voluntarily donating my organ(s) as specified in this form. 
                      I understand that this is a selfless act of charity and I or my family will not receive 
                      any monetary compensation for this donation.
                    </p>
                    <p className="text-sm text-gray-700">
                      I confirm that I am mentally sound and understand the implications of organ donation. 
                      I have read and understood all the terms and conditions related to organ donation.
                    </p>
                    <p className="text-sm text-gray-700">
                      I authorize medical professionals to use my organs for transplantation purposes to 
                      save the lives of others in need.
                    </p>
                  </div>

                  <div className="flex items-start space-x-3 p-4 bg-green-50 rounded-xl">
                    <input
                      type="checkbox"
                      name="consent"
                      checked={formData.consent}
                      onChange={handleChange}
                      required
                      className="mt-1 w-5 h-5 text-green-500 focus:ring-green-500 rounded"
                      data-testid="checkbox-consent"
                    />
                    <label className="text-sm text-gray-700">
                      <span className="font-semibold">I agree</span> to the terms and conditions mentioned above. 
                      I understand this is a demo application and no actual organ donation will be processed.
                    </label>
                  </div>

                  <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                    <p className="text-sm text-green-800">
                      ✓ Thank you for your noble decision. Your act of kindness will save lives!
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8">
              {step > 1 && (
                <motion.button
                  type="button"
                  onClick={prevStep}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 py-3 rounded-full border-2 border-gray-300 text-gray-700 font-semibold flex items-center space-x-2 hover:bg-gray-50 transition-all"
                  data-testid="btn-previous"
                >
                  <ChevronLeft size={20} />
                  <span>Previous</span>
                </motion.button>
              )}

              {step < 3 ? (
                <motion.button
                  type="button"
                  onClick={nextStep}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-secondary ml-auto flex items-center space-x-2"
                  data-testid="btn-next"
                >
                  <span>Next</span>
                  <ChevronRight size={20} />
                </motion.button>
              ) : (
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="btn-secondary ml-auto flex items-center space-x-2"
                  data-testid="btn-submit"
                >
                  <Check size={20} />
                  <span>Submit Registration</span>
                </motion.button>
              )}
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default OrganDonationForm;
