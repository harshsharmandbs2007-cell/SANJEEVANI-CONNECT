import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Building2, Users, Activity, TrendingUp, Droplet, Heart, FileText } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import FloatingWatermark from '../components/FloatingWatermark';
import AnimatedParticles from '../components/AnimatedParticles';

const HospitalPanel = () => {
  const [activeTab, setActiveTab] = useState('overview');

  const stats = {
    totalRequests: 245,
    activeDonors: 1840,
    bloodUnits: 580,
    organRequests: 45,
  };

  const bloodRequestData = [
    { month: 'Jan', requests: 45 },
    { month: 'Feb', requests: 52 },
    { month: 'Mar', requests: 48 },
    { month: 'Apr', requests: 65 },
    { month: 'May', requests: 58 },
    { month: 'Jun', requests: 72 },
  ];

  const bloodGroupData = [
    { name: 'A+', value: 25, color: '#ef4444' },
    { name: 'B+', value: 20, color: '#f97316' },
    { name: 'O+', value: 30, color: '#eab308' },
    { name: 'AB+', value: 10, color: '#22c55e' },
    { name: 'O-', value: 15, color: '#3b82f6' },
  ];

  const recentRequests = [
    { id: 'REQ001', patient: 'John Doe', bloodGroup: 'A+', units: 2, status: 'Pending', priority: 'High' },
    { id: 'REQ002', patient: 'Jane Smith', bloodGroup: 'O+', units: 1, status: 'Fulfilled', priority: 'Medium' },
    { id: 'REQ003', patient: 'Mike Johnson', bloodGroup: 'B+', units: 3, status: 'Processing', priority: 'High' },
    { id: 'REQ004', patient: 'Sarah Williams', bloodGroup: 'AB+', units: 2, status: 'Pending', priority: 'Low' },
  ];

  const donors = [
    { id: 'D001', name: 'Rahul Sharma', bloodGroup: 'A+', lastDonation: '2024-09-15', status: 'Active' },
    { id: 'D002', name: 'Priya Singh', bloodGroup: 'B+', lastDonation: '2024-10-20', status: 'Active' },
    { id: 'D003', name: 'Amit Kumar', bloodGroup: 'O+', lastDonation: '2024-08-10', status: 'Eligible' },
    { id: 'D004', name: 'Sneha Patel', bloodGroup: 'AB+', lastDonation: '2024-11-05', status: 'Active' },
  ];

  return (
    <div className="relative min-h-screen pt-24 pb-12 px-4">
      <AnimatedParticles />
      <FloatingWatermark />

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 mb-4">
            <Building2 className="text-blue-500" size={32} />
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold gradient-text mb-4">Hospital Panel</h1>
          <p className="text-gray-600">Manage blood requests and donor database</p>
        </motion.div>

        {/* Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {['overview', 'requests', 'donors', 'reports'].map((tab) => (
            <motion.button
              key={tab}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-3 rounded-full font-semibold capitalize transition-all ${
                activeTab === tab
                  ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg'
                  : 'bg-white/50 text-gray-700 hover:bg-white/70'
              }`}
              data-testid={`tab-${tab}`}
            >
              {tab}
            </motion.button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="glass-card p-6"
                data-testid="stat-total-requests"
              >
                <FileText className="text-blue-500 mb-3" size={32} />
                <h3 className="text-3xl font-bold text-gray-800">{stats.totalRequests}</h3>
                <p className="text-gray-600">Total Requests</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 }}
                className="glass-card p-6"
                data-testid="stat-active-donors"
              >
                <Users className="text-green-500 mb-3" size={32} />
                <h3 className="text-3xl font-bold text-gray-800">{stats.activeDonors}</h3>
                <p className="text-gray-600">Active Donors</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                className="glass-card p-6"
                data-testid="stat-blood-units"
              >
                <Droplet className="text-red-500 mb-3" size={32} />
                <h3 className="text-3xl font-bold text-gray-800">{stats.bloodUnits}</h3>
                <p className="text-gray-600">Blood Units Available</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 }}
                className="glass-card p-6"
                data-testid="stat-organ-requests"
              >
                <Heart className="text-purple-500 mb-3" size={32} />
                <h3 className="text-3xl font-bold text-gray-800">{stats.organRequests}</h3>
                <p className="text-gray-600">Organ Requests</p>
              </motion.div>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-card p-6"
              >
                <h2 className="text-xl font-bold mb-4 gradient-text">Blood Requests Trend</h2>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={bloodRequestData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="requests" stroke="#ef4444" strokeWidth={3} />
                  </LineChart>
                </ResponsiveContainer>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-card p-6"
              >
                <h2 className="text-xl font-bold mb-4 gradient-text">Blood Group Distribution</h2>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={bloodGroupData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {bloodGroupData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </motion.div>
            </div>
          </div>
        )}

        {/* Requests Tab */}
        {activeTab === 'requests' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="glass-card p-6"
          >
            <h2 className="text-2xl font-bold mb-6 gradient-text">Recent Blood Requests</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2 border-gray-200">
                    <th className="text-left p-4 font-semibold">Request ID</th>
                    <th className="text-left p-4 font-semibold">Patient</th>
                    <th className="text-left p-4 font-semibold">Blood Group</th>
                    <th className="text-left p-4 font-semibold">Units</th>
                    <th className="text-left p-4 font-semibold">Priority</th>
                    <th className="text-left p-4 font-semibold">Status</th>
                    <th className="text-left p-4 font-semibold">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {recentRequests.map((request, index) => (
                    <motion.tr
                      key={request.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="border-b border-gray-100 hover:bg-gray-50"
                      data-testid={`request-row-${index}`}
                    >
                      <td className="p-4 font-mono text-sm">{request.id}</td>
                      <td className="p-4">{request.patient}</td>
                      <td className="p-4">
                        <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full font-semibold">
                          {request.bloodGroup}
                        </span>
                      </td>
                      <td className="p-4">{request.units}</td>
                      <td className="p-4">
                        <span
                          className={`px-3 py-1 rounded-full font-semibold ${
                            request.priority === 'High'
                              ? 'bg-red-100 text-red-700'
                              : request.priority === 'Medium'
                              ? 'bg-yellow-100 text-yellow-700'
                              : 'bg-green-100 text-green-700'
                          }`}
                        >
                          {request.priority}
                        </span>
                      </td>
                      <td className="p-4">
                        <span
                          className={`px-3 py-1 rounded-full font-semibold ${
                            request.status === 'Fulfilled'
                              ? 'bg-green-100 text-green-700'
                              : request.status === 'Processing'
                              ? 'bg-blue-100 text-blue-700'
                              : 'bg-yellow-100 text-yellow-700'
                          }`}
                        >
                          {request.status}
                        </span>
                      </td>
                      <td className="p-4">
                        <button
                          onClick={() => alert(`Viewing request ${request.id} - Demo Mode`)}
                          className="px-4 py-2 bg-blue-500 text-white rounded-full hover:bg-blue-600 transition-all"
                        >
                          View
                        </button>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {/* Donors Tab */}
        {activeTab === 'donors' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="glass-card p-6"
          >
            <h2 className="text-2xl font-bold mb-6 gradient-text">Registered Donors</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2 border-gray-200">
                    <th className="text-left p-4 font-semibold">Donor ID</th>
                    <th className="text-left p-4 font-semibold">Name</th>
                    <th className="text-left p-4 font-semibold">Blood Group</th>
                    <th className="text-left p-4 font-semibold">Last Donation</th>
                    <th className="text-left p-4 font-semibold">Status</th>
                    <th className="text-left p-4 font-semibold">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {donors.map((donor, index) => (
                    <motion.tr
                      key={donor.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="border-b border-gray-100 hover:bg-gray-50"
                      data-testid={`donor-row-${index}`}
                    >
                      <td className="p-4 font-mono text-sm">{donor.id}</td>
                      <td className="p-4">{donor.name}</td>
                      <td className="p-4">
                        <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full font-semibold">
                          {donor.bloodGroup}
                        </span>
                      </td>
                      <td className="p-4">{donor.lastDonation}</td>
                      <td className="p-4">
                        <span
                          className={`px-3 py-1 rounded-full font-semibold ${
                            donor.status === 'Active'
                              ? 'bg-green-100 text-green-700'
                              : 'bg-blue-100 text-blue-700'
                          }`}
                        >
                          {donor.status}
                        </span>
                      </td>
                      <td className="p-4">
                        <button
                          onClick={() => alert(`Contacting ${donor.name} - Demo Mode`)}
                          className="px-4 py-2 bg-green-500 text-white rounded-full hover:bg-green-600 transition-all"
                        >
                          Contact
                        </button>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {/* Reports Tab */}
        {activeTab === 'reports' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="glass-card p-8"
          >
            <h2 className="text-2xl font-bold mb-6 gradient-text">Generate Reports</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-6 bg-red-50 rounded-xl text-center hover:shadow-lg transition-all cursor-pointer">
                <FileText className="text-red-500 mx-auto mb-4" size={48} />
                <h3 className="font-semibold text-lg mb-2">Monthly Blood Report</h3>
                <p className="text-sm text-gray-600 mb-4">Donations, requests, and inventory</p>
                <button
                  onClick={() => alert('Generating Monthly Report - Demo Mode')}
                  className="px-6 py-2 bg-red-500 text-white rounded-full hover:bg-red-600 transition-all"
                >
                  Generate
                </button>
              </div>

              <div className="p-6 bg-green-50 rounded-xl text-center hover:shadow-lg transition-all cursor-pointer">
                <Activity className="text-green-500 mx-auto mb-4" size={48} />
                <h3 className="font-semibold text-lg mb-2">Donor Activity Report</h3>
                <p className="text-sm text-gray-600 mb-4">Active donors and engagement</p>
                <button
                  onClick={() => alert('Generating Donor Report - Demo Mode')}
                  className="px-6 py-2 bg-green-500 text-white rounded-full hover:bg-green-600 transition-all"
                >
                  Generate
                </button>
              </div>

              <div className="p-6 bg-blue-50 rounded-xl text-center hover:shadow-lg transition-all cursor-pointer">
                <TrendingUp className="text-blue-500 mx-auto mb-4" size={48} />
                <h3 className="font-semibold text-lg mb-2">Trends Analysis</h3>
                <p className="text-sm text-gray-600 mb-4">6-month data analysis</p>
                <button
                  onClick={() => alert('Generating Trends Report - Demo Mode')}
                  className="px-6 py-2 bg-blue-500 text-white rounded-full hover:bg-blue-600 transition-all"
                >
                  Generate
                </button>
              </div>

              <div className="p-6 bg-purple-50 rounded-xl text-center hover:shadow-lg transition-all cursor-pointer">
                <Heart className="text-purple-500 mx-auto mb-4" size={48} />
                <h3 className="font-semibold text-lg mb-2">Organ Donation Report</h3>
                <p className="text-sm text-gray-600 mb-4">Registration and matching data</p>
                <button
                  onClick={() => alert('Generating Organ Report - Demo Mode')}
                  className="px-6 py-2 bg-purple-500 text-white rounded-full hover:bg-purple-600 transition-all"
                >
                  Generate
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default HospitalPanel;
