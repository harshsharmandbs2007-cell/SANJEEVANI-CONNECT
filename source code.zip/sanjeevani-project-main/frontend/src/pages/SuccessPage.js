import React, { useEffect, useRef } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, Download, Share2, Home } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import confetti from 'canvas-confetti';
import FloatingWatermark from '../components/FloatingWatermark';

const SuccessPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { donorId, type, formData } = location.state || {};

  useEffect(() => {
    if (!donorId) {
      navigate('/');
      return;
    }

    // Confetti animation
    const duration = 3000;
    const end = Date.now() + duration;

    const colors = ['#ef4444', '#22c55e', '#3b82f6'];

    (function frame() {
      confetti({
        particleCount: 3,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: colors,
      });
      confetti({
        particleCount: 3,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: colors,
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    })();
  }, [donorId, navigate]);

  const handleDownload = () => {
    alert('Certificate download initiated - Demo Mode');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Sanjeevani Donor Certificate',
        text: `I just registered as a ${type} donor with Sanjeevani! Donor ID: ${donorId}`,
      });
    } else {
      alert('Sharing - Demo Mode\nDonor ID: ' + donorId);
    }
  };

  if (!donorId) return null;

  return (
    <div className="relative min-h-screen pt-24 pb-12 px-4">
      <FloatingWatermark />

      <div className="max-w-4xl mx-auto">
        {/* Success Message */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', duration: 0.6 }}
          className="text-center mb-12"
        >
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="inline-block mb-6"
          >
            <CheckCircle className="text-green-500" size={100} />
          </motion.div>
          <h1 className="text-4xl sm:text-5xl font-bold gradient-text mb-4">
            Registration Successful!
          </h1>
          <p className="text-xl text-gray-600">
            Thank you for being a lifesaver, {formData?.name}!
          </p>
        </motion.div>

        {/* Certificate */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-card p-8 sm:p-12 mb-8 relative overflow-hidden"
          data-testid="certificate-card"
        >
          {/* Watermark Background */}
          <div className="absolute inset-0 flex items-center justify-center opacity-5">
            <img src="/watermark.png" alt="" className="w-full h-full object-contain" />
          </div>

          <div className="relative z-10">
            {/* Certificate Header */}
            <div className="text-center mb-8 border-b-4 border-gradient-to-r from-red-500 via-green-500 to-blue-500 pb-6">
              <img
                src="/logo.jpeg"
                alt="Sanjeevani"
                className="h-20 w-20 mx-auto rounded-full logo-glow object-cover mb-4"
              />
              <h2 className="text-3xl font-bold gradient-text mb-2">SANJEEVANI</h2>
              <p className="text-gray-600">Certificate of {type === 'blood' ? 'Blood' : 'Organ'} Donation</p>
            </div>

            {/* Certificate Body */}
            <div className="text-center space-y-6">
              <p className="text-lg text-gray-700">
                This is to certify that
              </p>
              <h3 className="text-3xl font-bold text-gray-800">{formData?.name}</h3>
              <p className="text-lg text-gray-700">
                has registered as a {type === 'blood' ? 'Blood' : 'Organ'} Donor
              </p>

              <div className="flex justify-center items-center space-x-8 my-8">
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-2">Donor ID</p>
                  <p className="text-2xl font-bold text-blue-600">{donorId}</p>
                </div>
                <div className="bg-white p-4 rounded-xl shadow-lg">
                  <QRCodeSVG value={`SANJEEVANI-${donorId}`} size={100} />
                </div>
              </div>

              {type === 'blood' && formData?.bloodGroup && (
                <div className="inline-block bg-red-100 px-8 py-4 rounded-full">
                  <p className="text-sm text-gray-600 mb-1">Blood Group</p>
                  <p className="text-3xl font-bold text-red-600">{formData.bloodGroup}</p>
                </div>
              )}

              {type === 'organ' && formData?.organType && (
                <div className="inline-block bg-green-100 px-8 py-4 rounded-full">
                  <p className="text-sm text-gray-600 mb-1">Organ Type</p>
                  <p className="text-2xl font-bold text-green-600">{formData.organType}</p>
                </div>
              )}

              <div className="pt-6 border-t border-gray-200">
                <p className="text-sm text-gray-500">
                  Registration Date: {new Date().toLocaleDateString('en-IN', { 
                    day: 'numeric', 
                    month: 'long', 
                    year: 'numeric' 
                  })}
                </p>
              </div>
            </div>

            {/* Certificate Footer */}
            <div className="mt-8 pt-6 border-t border-gray-200 text-center">
              <p className="text-sm text-gray-600 italic">
                "Every donation is a step towards saving a life. Thank you for your noble contribution."
              </p>
            </div>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="flex flex-wrap justify-center gap-4"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleDownload}
            className="btn-primary flex items-center space-x-2"
            data-testid="btn-download"
          >
            <Download size={20} />
            <span>Download Certificate</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleShare}
            className="btn-secondary flex items-center space-x-2"
            data-testid="btn-share"
          >
            <Share2 size={20} />
            <span>Share</span>
          </motion.button>

          <Link to="/dashboard">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn-tertiary flex items-center space-x-2"
              data-testid="btn-dashboard"
            >
              <Home size={20} />
              <span>Go to Dashboard</span>
            </motion.button>
          </Link>
        </motion.div>

        {/* Next Steps */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="mt-12 glass-card p-8"
        >
          <h3 className="text-2xl font-bold mb-4 text-center gradient-text">What's Next?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-4xl mb-3">📱</div>
              <h4 className="font-semibold mb-2">Stay Connected</h4>
              <p className="text-sm text-gray-600">We'll notify you when someone needs your help</p>
            </div>
            <div className="text-center">
              <div className="text-4xl mb-3">🏆</div>
              <h4 className="font-semibold mb-2">Earn Badges</h4>
              <p className="text-sm text-gray-600">Collect badges for each donation milestone</p>
            </div>
            <div className="text-center">
              <div className="text-4xl mb-3">💝</div>
              <h4 className="font-semibold mb-2">Special Benefits</h4>
              <p className="text-sm text-gray-600">Access exclusive donor benefits and recognition</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default SuccessPage;
