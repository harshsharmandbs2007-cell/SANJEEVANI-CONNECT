import React from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from 'sonner';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ParallaxBackground from './components/ParallaxBackground';
import DualWatermark from './components/DualWatermark';
import HomePage from './pages/HomePage';
import BloodDonationForm from './pages/BloodDonationForm';
import OrganDonationForm from './pages/OrganDonationForm';
import EnhancedOrganDonationForm from './pages/EnhancedOrganDonationForm';
import SuccessPage from './pages/SuccessPage';
import DonorDashboard from './pages/DonorDashboard';
import EmergencyPage from './pages/EmergencyPage';
import HospitalPanel from './pages/HospitalPanel';
import MedicineStore from './pages/MedicineStore';
import UserStatusTracking from './pages/UserStatusTracking';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <ParallaxBackground>
          <Navbar />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/donate-blood" element={<BloodDonationForm />} />
            <Route path="/donate-organ" element={<EnhancedOrganDonationForm />} />
            <Route path="/success" element={<SuccessPage />} />
            <Route path="/dashboard" element={<DonorDashboard />} />
            <Route path="/emergency" element={<EmergencyPage />} />
            <Route path="/hospital" element={<HospitalPanel />} />
            <Route path="/medicine-store" element={<MedicineStore />} />
            <Route path="/status" element={<UserStatusTracking />} />
          </Routes>
          <Footer />
          <Toaster position="top-right" richColors />
        </ParallaxBackground>
      </BrowserRouter>
    </div>
  );
}

export default App;
