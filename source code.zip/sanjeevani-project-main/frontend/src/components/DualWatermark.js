import React from 'react';
import { motion } from 'framer-motion';

const DualWatermark = () => {
  return (
    <>
      {/* Primary: Logo Watermark - Vertical Floating */}
      <div className="fixed left-8 top-1/4 z-0 pointer-events-none hidden lg:block">
        <motion.div
          animate={{
            y: [0, -30, 0],
            rotate: [0, 5, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="relative"
        >
          <div className="glass opacity-5 p-4 rounded-2xl backdrop-blur-xl">
            <img
              src="/logo.jpeg"
              alt=""
              className="w-20 h-20 rounded-full blur-[1px] grayscale"
            />
            <div className="mt-2 text-center">
              <p className="text-xs font-bold text-gray-600 blur-[0.5px]">SANJEEVANI</p>
              <p className="text-[8px] text-gray-500 blur-[0.5px]">When Seconds Matter</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Secondary: Logo Watermark - Right Side */}
      <div className="fixed right-8 bottom-1/4 z-0 pointer-events-none hidden lg:block">
        <motion.div
          animate={{
            y: [0, 30, 0],
            rotate: [0, -5, 0],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: 2,
          }}
          className="relative"
        >
          <div className="glass opacity-5 p-4 rounded-2xl backdrop-blur-xl">
            <img
              src="/logo.jpeg"
              alt=""
              className="w-20 h-20 rounded-full blur-[1px] grayscale"
            />
          </div>
        </motion.div>
      </div>

      {/* Banner Watermark - Full Screen Slow Drift */}
      <motion.div
        animate={{
          x: [0, 50, 0],
          y: [0, 30, 0],
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="fixed inset-0 z-0 pointer-events-none overflow-hidden"
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <img
            src="/watermark.png"
            alt=""
            className="w-full h-full object-contain opacity-[0.08] blur-[3px] grayscale"
            style={{
              filter: 'blur(3px) grayscale(0.5)',
              mixBlendMode: 'multiply',
            }}
          />
        </div>
      </motion.div>

      {/* Floating Logo Watermarks - Multiple Instances */}
      <FloatingLogoInstances />

      {/* Text Watermark - Diagonal */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <motion.div
          animate={{
            rotate: [45, 46, 45],
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="absolute inset-0 flex items-center justify-center"
        >
          <div className="text-[120px] font-bold text-gray-400 opacity-[0.02] select-none whitespace-nowrap">
            SANJEEVANI • WHEN SECONDS MATTER • SANJEEVANI • WHEN SECONDS MATTER •
          </div>
        </motion.div>
      </div>
    </>
  );
};

// Floating Logo Instances at Different Positions
const FloatingLogoInstances = () => {
  const positions = [
    { top: '10%', left: '10%', delay: 0, duration: 12 },
    { top: '20%', right: '15%', delay: 2, duration: 15 },
    { bottom: '15%', left: '15%', delay: 4, duration: 18 },
    { bottom: '25%', right: '20%', delay: 6, duration: 14 },
  ];

  return (
    <>
      {positions.map((pos, index) => (
        <motion.div
          key={index}
          style={pos}
          animate={{
            y: [0, -20, 0],
            rotate: [0, 10, 0],
            opacity: [0.03, 0.05, 0.03],
          }}
          transition={{
            duration: pos.duration,
            repeat: Infinity,
            ease: 'easeInOut',
            delay: pos.delay,
          }}
          className="fixed z-0 pointer-events-none hidden xl:block"
        >
          <img
            src="/logo.jpeg"
            alt=""
            className="w-16 h-16 rounded-full blur-[2px] grayscale opacity-50"
          />
        </motion.div>
      ))}
    </>
  );
};

export default DualWatermark;
