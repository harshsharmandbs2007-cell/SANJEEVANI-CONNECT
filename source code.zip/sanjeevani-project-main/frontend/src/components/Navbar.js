import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Heart, Droplet, AlertCircle, Building2, ShoppingBag, LayoutDashboard, Activity } from 'lucide-react';
import { motion } from 'framer-motion';

const Navbar = () => {
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'Home', icon: null },
    { path: '/donate-blood', label: 'Donate Blood', icon: Droplet },
    { path: '/donate-organ', label: 'Donate Organ', icon: Heart },
    { path: '/emergency', label: 'Emergency', icon: AlertCircle },
    { path: '/hospital', label: 'Hospital', icon: Building2 },
    { path: '/medicine-store', label: 'Medicine', icon: ShoppingBag },
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/status', label: 'Track Status', icon: Activity },
  ];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 w-full z-50 glass"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3">
            <motion.img
              whileHover={{ scale: 1.05 }}
              src="/logo.jpeg"
              alt="Sanjeevani"
              className="h-14 w-14 rounded-full logo-glow object-cover"
            />
            <div>
              <h1 className="text-xl font-bold gradient-text">SANJEEVANI</h1>
              <p className="text-xs text-gray-600">When Seconds Matter</p>
            </div>
          </Link>

          {/* Navigation Links */}
          <div className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`px-4 py-2 rounded-full font-medium transition-all flex items-center space-x-2 ${
                    isActive
                      ? 'bg-gradient-to-r from-red-500 to-blue-500 text-white shadow-lg'
                      : 'text-gray-700 hover:bg-white/50'
                  }`}
                >
                  {Icon && <Icon size={16} />}
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden">
            <button className="p-2 rounded-lg hover:bg-white/50">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </motion.nav>
  );
};

export default Navbar;
