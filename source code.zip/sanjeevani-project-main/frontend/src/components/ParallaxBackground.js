import React, { useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';

const ParallaxBackground = ({ children }) => {
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll();
  
  // Smooth parallax values
  const y1 = useSpring(useTransform(scrollYProgress, [0, 1], [0, -200]), { stiffness: 100, damping: 30 });
  const y2 = useSpring(useTransform(scrollYProgress, [0, 1], [0, -100]), { stiffness: 100, damping: 30 });
  const y3 = useSpring(useTransform(scrollYProgress, [0, 1], [0, -50]), { stiffness: 100, damping: 30 });
  
  const opacity1 = useTransform(scrollYProgress, [0, 0.5, 1], [0.6, 0.3, 0.1]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.2]);

  return (
    <div ref={containerRef} className="relative">
      {/* Layer 1: Banner Watermark - Deepest */}
      <motion.div
        style={{ y: y1, scale, opacity: opacity1 }}
        className="fixed inset-0 z-0 pointer-events-none"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-red-50 via-green-50 to-blue-50 opacity-40" />
        <img
          src="/watermark.png"
          alt=""
          className="w-full h-full object-cover opacity-10 blur-[2px]"
          style={{ mixBlendMode: 'multiply' }}
        />
      </motion.div>

      {/* Layer 2: Medical Grid Pattern */}
      <motion.div
        style={{ y: y2 }}
        className="fixed inset-0 z-0 pointer-events-none opacity-5"
      >
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="medical-grid" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
              <circle cx="50" cy="50" r="1.5" fill="#ef4444" opacity="0.3" />
              <circle cx="50" cy="50" r="1" fill="#22c55e" opacity="0.3" />
              <path d="M 45 50 L 55 50 M 50 45 L 50 55" stroke="#3b82f6" strokeWidth="1" opacity="0.2" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#medical-grid)" />
        </svg>
      </motion.div>

      {/* Layer 3: Animated Particles */}
      <motion.div
        style={{ y: y3 }}
        className="fixed inset-0 z-0 pointer-events-none"
      >
        <AnimatedMedicalParticles />
      </motion.div>

      {/* Layer 4: Content */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
};

// Animated Medical Particles Component
const AnimatedMedicalParticles = () => {
  const particles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 4 + 2,
    duration: Math.random() * 15 + 10,
    delay: Math.random() * 5,
    type: ['heart', 'cross', 'drop'][Math.floor(Math.random() * 3)],
  }));

  return (
    <>
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className="absolute"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
          }}
          animate={{
            y: [0, -150, 0],
            x: [0, Math.sin(particle.id) * 30, 0],
            rotate: [0, 360],
            opacity: [0.2, 0.6, 0.2],
            scale: [1, 1.5, 1],
          }}
          transition={{
            duration: particle.duration,
            repeat: Infinity,
            delay: particle.delay,
            ease: 'easeInOut',
          }}
        >
          {particle.type === 'heart' && (
            <svg width={particle.size * 2} height={particle.size * 2} viewBox="0 0 24 24" fill="none">
              <path
                d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
                fill="#22c55e"
                opacity="0.4"
              />
            </svg>
          )}
          {particle.type === 'cross' && (
            <svg width={particle.size * 2} height={particle.size * 2} viewBox="0 0 24 24" fill="none">
              <path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6V3z" fill="#3b82f6" opacity="0.4" />
            </svg>
          )}
          {particle.type === 'drop' && (
            <svg width={particle.size * 2} height={particle.size * 2} viewBox="0 0 24 24" fill="none">
              <path
                d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"
                fill="#ef4444"
                opacity="0.4"
              />
            </svg>
          )}
        </motion.div>
      ))}
    </>
  );
};

export default ParallaxBackground;
