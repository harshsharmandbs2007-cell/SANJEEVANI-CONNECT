import React, { useEffect } from 'react';
import { toast } from 'sonner';
import { Bell, Heart, Droplet, CheckCircle, Award } from 'lucide-react';

// Demo notification system for SANJEEVANI
export const showDemoNotifications = () => {
  // Simulate notifications that would appear in a real system
  
  setTimeout(() => {
    toast.success('Request Sent Successfully', {
      description: 'Your donation request has been sent to nearby hospitals.',
      icon: <CheckCircle size={20} />,
      duration: 4000,
    });
  }, 2000);
};

export const showDonorFoundNotification = () => {
  toast.success('Donor Found!', {
    description: 'A matching donor has been located near you.',
    icon: <Droplet size={20} />,
    duration: 5000,
  });
};

export const showCertificateReadyNotification = () => {
  toast.success('Certificate Ready', {
    description: 'Your donation certificate is ready to download.',
    icon: <Award size={20} />,
    duration: 5000,
  });
};

export const showEmergencyAlert = () => {
  toast.error('Emergency Alert', {
    description: 'Urgent blood requirement - Please respond if available.',
    icon: <Bell size={20} />,
    duration: 6000,
  });
};

export const showThankYouNotification = (name) => {
  toast.success(`Thank you, ${name}!`, {
    description: 'Your contribution will save lives. You are a hero!',
    icon: <Heart size={20} />,
    duration: 5000,
  });
};

// Custom notification component
export const NotificationToast = ({ title, message, type = 'info', icon }) => {
  return (
    <div className="flex items-start space-x-3 p-4 bg-white rounded-xl shadow-lg border border-gray-200">
      <div className={`flex-shrink-0 ${
        type === 'success' ? 'text-green-500' :
        type === 'error' ? 'text-red-500' :
        type === 'warning' ? 'text-yellow-500' :
        'text-blue-500'
      }`}>
        {icon}
      </div>
      <div>
        <h4 className="font-semibold text-gray-800 mb-1">{title}</h4>
        <p className="text-sm text-gray-600">{message}</p>
      </div>
    </div>
  );
};

export default NotificationToast;
