import React from 'react';

const FloatingWatermark = () => {
  return (
    <>
      <img 
        src="/watermark.png" 
        alt="" 
        className="floating-watermark"
        style={{ animationDelay: '0s' }}
      />
      <img 
        src="/watermark.png" 
        alt="" 
        className="floating-watermark"
        style={{ animationDelay: '12.5s' }}
      />
    </>
  );
};

export default FloatingWatermark;
