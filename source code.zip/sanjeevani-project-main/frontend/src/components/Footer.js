import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="relative mt-20 glass">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <img
                src="/logo.jpeg"
                alt="Sanjeevani"
                className="h-12 w-12 rounded-full logo-glow object-cover"
              />
              <div>
                <h3 className="text-xl font-bold gradient-text">SANJEEVANI</h3>
                <p className="text-sm text-gray-600">When Seconds Matter</p>
              </div>
            </div>
            <p className="text-gray-600 mb-4">
              Connecting lives in real-time. Every donation counts. Be a lifesaver today.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-red-500 hover:text-red-600 transition-colors">
                <Heart size={24} fill="currentColor" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-gray-800 mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link to="/donate-blood" className="text-gray-600 hover:text-red-500 transition-colors">Donate Blood</Link></li>
              <li><Link to="/donate-organ" className="text-gray-600 hover:text-green-500 transition-colors">Donate Organ</Link></li>
              <li><Link to="/emergency" className="text-gray-600 hover:text-blue-500 transition-colors">Emergency</Link></li>
              <li><Link to="/dashboard" className="text-gray-600 hover:text-purple-500 transition-colors">Dashboard</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-gray-800 mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center space-x-2 text-gray-600">
                <Phone size={16} />
                <span>1800-123-4567</span>
              </li>
              <li className="flex items-center space-x-2 text-gray-600">
                <Mail size={16} />
                <span>help@sanjeevani.in</span>
              </li>
              <li className="flex items-center space-x-2 text-gray-600">
                <MapPin size={16} />
                <span>Mumbai, India</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-8 pt-8 text-center text-gray-600 text-sm">
          <p>&copy; {new Date().getFullYear()} Sanjeevani Connect. All rights reserved.</p>
          <div className="mt-2 space-x-4">
            <button onClick={() => alert('Privacy Policy - Demo Mode')} className="hover:text-red-500 transition-colors">Privacy Policy</button>
            <button onClick={() => alert('Terms of Service - Demo Mode')} className="hover:text-red-500 transition-colors">Terms</button>
            <button onClick={() => alert('Security Info - Demo Mode')} className="hover:text-red-500 transition-colors">Security</button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
